#include "main.h"
#include "adf4351.h"
extern SPI_HandleTypeDef hspi1;
ADF4351_HandleTypeDef adf={
 .hspi=&hspi1,
 .le_port=GPIOA,.le_pin=GPIO_PIN_4,
 .ce_port=GPIOB,.ce_pin=GPIO_PIN_0,
 .ld_port=GPIOA,.ld_pin=GPIO_PIN_1,
 .ref_hz=10000000UL,.r_counter=1,.ref_doubler=0,.ref_div2=0,
 .output_power=3,.mute_till_lock=0
};
void ADF4351_UserInit(void){ADF4351_Init(&adf);}
void ADF4351_UserTest(void){
 ADF4351_SetFrequency(&adf,100000000ULL);HAL_Delay(500);
 ADF4351_SetFrequency(&adf,200000000ULL);HAL_Delay(500);
 ADF4351_SetFrequency(&adf,500000000ULL);HAL_Delay(500);
 ADF4351_SetFrequency(&adf,1000000000ULL);HAL_Delay(500);
}
