STM32G031K8T6 ADF4351 firmware
================================
PCB mapping:
PA4/U5-11 -> U3-3 LE
PA5/U5-12 -> U3-1 CLK
PA7/U5-14 -> U3-2 DATA
PB0/U5-15 -> U3-4 CE
PA1/U5-8  <- U3-25 LD

Configure SPI1 as Master, 8-bit, MSB first, CPOL=LOW, CPHA=1EDGE,
software NSS. ST's STM32CubeG0 examples include SPI polling examples
for the G031 family.

Copy adf4351.c to Core/Src and adf4351.h to Core/Inc.
Use the main.c.snippet in the USER CODE section after MX initialization.

This driver assumes a 10 MHz TCXO, R=1, no reference doubler/div2,
and selects the RF output divider to keep VCO in 2.2-4.4 GHz.
The frequency routine uses MOD=4095.


