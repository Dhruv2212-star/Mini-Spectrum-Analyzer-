#include "adf4351.h"
#define TIMEOUT 100U
static uint32_t R[6];
static void LE(ADF4351_HandleTypeDef*d){HAL_GPIO_WritePin(d->le_port,d->le_pin,GPIO_PIN_SET);__NOP();__NOP();HAL_GPIO_WritePin(d->le_port,d->le_pin,GPIO_PIN_RESET);}
HAL_StatusTypeDef ADF4351_WriteRaw(ADF4351_HandleTypeDef*d,uint32_t v){
 uint8_t b[4]={(uint8_t)(v>>24),(uint8_t)(v>>16),(uint8_t)(v>>8),(uint8_t)v};
 HAL_StatusTypeDef s=HAL_SPI_Transmit(d->hspi,b,4,TIMEOUT); if(s!=HAL_OK)return s; LE(d); return HAL_OK;
}
static uint32_t gcd(uint32_t a,uint32_t b){while(b){uint32_t t=a%b;a=b;b=t;}return a;}
static uint32_t outdiv(uint64_t*v){static const uint32_t d[]={1,2,4,8,16,32,64};for(uint32_t i=0;i<7;i++){uint64_t x=*v*d[i];if(x>=2200000000ULL&&x<=4400000000ULL){*v=x;return i;}}return 0xFFFFFFFFUL;}
static HAL_StatusTypeDef program(ADF4351_HandleTypeDef*d){
 HAL_StatusTypeDef s; for(int i=5;i>=0;i--){s=ADF4351_WriteRaw(d,R[i]);if(s!=HAL_OK)return s;} return HAL_OK;
}
HAL_StatusTypeDef ADF4351_SetFrequencyFrac(ADF4351_HandleTypeDef*d,uint64_t f,uint16_t mod){
 if(!d||!d->hspi||mod<2||mod>4095||f<35000000ULL||f>4400000000ULL)return HAL_ERROR;
 uint64_t vco=f;uint32_t od=outdiv(&vco);if(od==0xFFFFFFFFUL)return HAL_ERROR;
 uint64_t pfd=(uint64_t)d->ref_hz*(d->ref_doubler?2:1)/d->r_counter;if(d->ref_div2)pfd/=2;
 if(!pfd||pfd>32000000ULL)return HAL_ERROR;
 uint64_t n_num=vco*mod,n_den=pfd*mod;
 uint64_t ni=n_num/n_den, rem=n_num%n_den;
 uint32_t frac=(uint32_t)((rem+pfd/2)/pfd);
 if(frac>=mod){ni++;frac=0;}
 uint8_t pres=(ni>=75);
 if((!pres&&ni<23)||(pres&&ni<75)||ni>65535)return HAL_ERROR;
 R[0]=((uint32_t)ni<<15)|((frac&0xFFFU)<<3);
 R[1]=(1UL<<27)|((uint32_t)mod<<3)|1UL;
 R[2]=(1UL<<29)|(1UL<<8)|2UL; /* digital lock detect, integer-N LDF */
 R[3]=(80UL<<3)|3UL; 
 R[4]=(1UL<<23)|((od&7UL)<<20)|((uint32_t)(d->mute_till_lock?1:0)<<5)|((uint32_t)(d->output_power&3)<<3)|4UL;
 R[5]=(3UL<<3)|5UL;
 return program(d);
}
HAL_StatusTypeDef ADF4351_SetFrequency(ADF4351_HandleTypeDef*d,uint64_t f){return ADF4351_SetFrequencyFrac(d,f,4095);}
HAL_StatusTypeDef ADF4351_SetRFPower(ADF4351_HandleTypeDef*d,uint8_t p){if(!d||p>3)return HAL_ERROR;d->output_power=p;R[4]=(R[4]&~(3UL<<3))|((uint32_t)p<<3);return ADF4351_WriteRaw(d,R[4]);}
HAL_StatusTypeDef ADF4351_RFEnable(ADF4351_HandleTypeDef*d,uint8_t e){if(!d)return HAL_ERROR;R[4]&=~(1UL<<5);if(e)R[4]|=1UL<<5;return ADF4351_WriteRaw(d,R[4]);}
uint8_t ADF4351_IsLocked(ADF4351_HandleTypeDef*d){return d&&d->ld_port&&HAL_GPIO_ReadPin(d->ld_port,d->ld_pin)==GPIO_PIN_SET;}
HAL_StatusTypeDef ADF4351_Init(ADF4351_HandleTypeDef*d){
 if(!d||!d->hspi)return HAL_ERROR;if(!d->ref_hz)d->ref_hz=10000000UL;if(!d->r_counter)d->r_counter=1;
 HAL_GPIO_WritePin(d->ce_port,d->ce_pin,GPIO_PIN_SET);HAL_GPIO_WritePin(d->le_port,d->le_pin,GPIO_PIN_RESET);
 return ADF4351_SetFrequency(d,100000000ULL);
}
