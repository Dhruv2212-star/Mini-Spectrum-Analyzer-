#ifndef ADF4351_H
#define ADF4351_H
#include "main.h"
#include "spi.h"
typedef struct {
 SPI_HandleTypeDef *hspi;
 GPIO_TypeDef *le_port; uint16_t le_pin;
 GPIO_TypeDef *ce_port; uint16_t ce_pin;
 GPIO_TypeDef *ld_port; uint16_t ld_pin;
 uint32_t ref_hz; uint16_t r_counter;
 uint8_t ref_doubler, ref_div2, output_power, mute_till_lock;
} ADF4351_HandleTypeDef;
HAL_StatusTypeDef ADF4351_Init(ADF4351_HandleTypeDef*);
HAL_StatusTypeDef ADF4351_SetFrequency(ADF4351_HandleTypeDef*, uint64_t);
HAL_StatusTypeDef ADF4351_SetFrequencyFrac(ADF4351_HandleTypeDef*,uint64_t,uint16_t);
HAL_StatusTypeDef ADF4351_SetRFPower(ADF4351_HandleTypeDef*,uint8_t);
HAL_StatusTypeDef ADF4351_RFEnable(ADF4351_HandleTypeDef*,uint8_t);
uint8_t ADF4351_IsLocked(ADF4351_HandleTypeDef*);
HAL_StatusTypeDef ADF4351_WriteRaw(ADF4351_HandleTypeDef*,uint32_t);
#endif
